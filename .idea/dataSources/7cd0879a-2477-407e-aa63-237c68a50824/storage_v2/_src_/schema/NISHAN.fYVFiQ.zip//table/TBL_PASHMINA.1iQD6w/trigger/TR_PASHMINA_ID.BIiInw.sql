create trigger TR_PASHMINA_ID
  before insert
  on TBL_PASHMINA
  for each row
  when (NEW.pashmina_id IS NULL)
  BEGIN 
    SELECT sq_pashmina_id.NEXTVAL
    INTO :NEW.pashmina_id
    FROM DUAL;
END;
/

