create trigger TR_USER_ROLE
  before insert
  on TBL_USER_ROLE
  for each row
  BEGIN
    SELECT sq_user_role_id.NEXTVAL
    INTO :NEW.user_role_id
    FROM dual;
END;
/

