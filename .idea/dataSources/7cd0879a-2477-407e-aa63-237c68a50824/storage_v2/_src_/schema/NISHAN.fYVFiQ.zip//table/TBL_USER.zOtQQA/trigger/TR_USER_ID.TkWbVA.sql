create trigger TR_USER_ID
  before insert
  on TBL_USER
  for each row
  BEGIN 
    SELECT sq_user_id.NEXTVAL
    INTO :NEW.user_id
    FROM DUAL;
END;
/

