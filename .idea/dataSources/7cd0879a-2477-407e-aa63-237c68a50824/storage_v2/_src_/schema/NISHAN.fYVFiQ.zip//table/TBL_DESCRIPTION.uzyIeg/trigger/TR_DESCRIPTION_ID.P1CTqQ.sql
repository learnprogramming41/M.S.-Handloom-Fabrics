create trigger TR_DESCRIPTION_ID
  before insert
  on TBL_DESCRIPTION
  for each row
  BEGIN 
    SELECT sq_description_id.NEXTVAL
    INTO :NEW.description_id
    FROM DUAL;
END;
/

