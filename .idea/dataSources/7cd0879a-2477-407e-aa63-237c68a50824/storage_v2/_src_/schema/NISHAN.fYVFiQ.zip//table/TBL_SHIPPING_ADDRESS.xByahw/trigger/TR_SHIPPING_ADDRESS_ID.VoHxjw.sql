create trigger TR_SHIPPING_ADDRESS_ID
  before insert
  on TBL_SHIPPING_ADDRESS
  for each row
  BEGIN 
    SELECT sq_shipping_address_id.NEXTVAL
    INTO :NEW.shipping_address_id
    FROM DUAL;
END;
/

