create trigger TR_USER_USER_ROLE
  after insert
  on TBL_USER
  for each row
  BEGIN
    IF :NEW.USER_TYPE = 'admin' THEN
        INSERT INTO tbl_user_role(username, user_role) VALUES(:NEW.username, 'ROLE_ADMIN');    
    ELSE 
        INSERT INTO tbl_user_role(username, user_role) VALUES(:NEW.username, 'ROLE_USER');
    END IF;
END;
/

