create trigger TR_COLOUR_ID
  before insert
  on TBL_PASHMINA_COLOUR
  for each row
  BEGIN 
    SELECT sq_colour_id.NEXTVAL
    INTO :NEW.colour_id
    FROM DUAL;
END;
/

