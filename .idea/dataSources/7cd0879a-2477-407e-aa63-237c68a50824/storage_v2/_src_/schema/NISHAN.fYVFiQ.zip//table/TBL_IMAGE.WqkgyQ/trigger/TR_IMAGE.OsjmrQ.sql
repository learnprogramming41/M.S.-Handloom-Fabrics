create trigger TR_IMAGE
  before insert
  on TBL_IMAGE
  for each row
  BEGIN
    SELECT SQ_IMAGE.NEXTVAL INTO :NEW.IMAGE_ID FROM DUAL;
END;
/

