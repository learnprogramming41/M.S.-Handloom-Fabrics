create trigger TR_ORDER_ID
  before insert
  on TBL_ORDER
  for each row
  BEGIN 
    SELECT sq_order_id.NEXTVAL
    INTO :NEW.order_id
    FROM DUAL;
END;
/

